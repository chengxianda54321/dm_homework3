load 'Survived.mat';
load 'Pclass.mat';
load 'Sex.mat';
load 'Age.mat';
load 'SibSp.mat';
load 'Parch.mat';
load 'Fare.mat';
load 'Embarked.mat'
M=nanmean(Age);
Age(isnan(Age))=M;
Embarked(62,1)=Embarked(61,1);
Embarked(830,1)=Embarked(829,1);
Sex=Sex-1;
sample=[Survived Sex Age SibSp Parch Fare Pclass];
[m,n]=size(sample);  
for i=1:n
    sample(:,i)=sample(:,i)/norm(sample(:,i));
end
sample1=[sample(:,3) sample(:,6)];
[Idx,C]=kmeans(sample,2);
 for i=1:891
   if Idx(i,1)==1 
      plot(sample1(i,1),sample1(i,2),'r*') % ��ʾ��һ��
     %plot(x(i,2),'r*') % ��ʾ��һ��
     hold on 
   else if Idx(i,1)==2
         plot(sample1(i,1),sample1(i,2),'b*') %��ʾ�ڶ��� 
        %  plot(x(i,2),'b*') % ��ʾ��һ��
          hold on 
       else if Idx(i,1)==3 
             plot(sample1(i,1),sample1(i,2),'g*') %��ʾ������ 
                    % plot(x(i,2),'g*') % ��ʾ��һ��
             hold on 
          else if Idx(i,1)==4
                 plot(sample1(i,1),sample1(i,2),'k*') %��ʾ������
                         % plot(x(i,2),'k*') % ��ʾ��һ��
                  hold on 
           end 
       end 
    end 
  end 
 end 
